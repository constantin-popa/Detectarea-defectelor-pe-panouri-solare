# yolov8 > 2024-05-21 1:53am
https://universe.roboflow.com/solar-panel-defect-detection/yolov8-4qenz

Provided by a Roboflow user
License: BY-NC-SA 4.0

